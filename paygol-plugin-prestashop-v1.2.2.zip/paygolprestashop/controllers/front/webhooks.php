<?php

/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2022 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

use Paygol\PaygolCore\PaygolApi;

class PaygolPrestaShopWebhooksModuleFrontController extends ModuleFrontController
{
    /** @var bool If set to true, will be redirected to authentication page */
    public $auth = false;

    /** @var bool */
    public $ajax;

    public function display()
    {
        try {
            http_response_code(400);

            PrestaShopLogger::addLog('IPN notification received', 2);

            $content_json  = file_get_contents('php://input');
            $payload = json_decode($content_json, true);

            ksort($payload);

            // Get headers
            $headers = getallheaders();

            $signature = $this->computeSignature(json_encode($payload, JSON_PRESERVE_ZERO_FRACTION), Configuration::get('TOKEN_SECRET'));

            // Check data integrity
            if (empty($headers['X-Pg-Sig']) || $headers['X-Pg-Sig'] !== $signature) {
                PrestaShopLogger::addLog('Error al validar la firma del mensaje', 2);
                PrestaShopLogger::addLog('Server signature: ' . ($headers['X-Pg-Sig'] ?? 'Empty'), 2);
                PrestaShopLogger::addLog('PS calculated signature: ' . $signature, 2);
                exit('Error al validar la firma del mensaje');
            }

            $cartId = htmlspecialchars(($payload['custom'] ?? ''));
            $paygolTransactionId = htmlspecialchars(($payload['transaction_id'] ?? ''));
            $paygolStatus = htmlspecialchars(($payload['status'] ?? ''));

            // Payment with error or was cancelled
            if ($paygolStatus !== 'completed') {
                error_log("Paygol status != completed {$paygolStatus}");
                exit('Estado de la transacción no es completed: ' . $paygolStatus);
            }

            if (!$this->checkStatus($paygolTransactionId)) {
                error_log("Error al checkear el estado");
                exit('Error al validar el estado de la transacción');
            }

            // Get Order by Cart Id
            $orderId = Order::getOrderByCartId((int) $cartId);

            $this->markAsCompleted($orderId);

            http_response_code(201);
        } catch (\Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 2);
        }
    }

    private function computeSignature($msg, $secret)
    {
        return hash_hmac('sha256', $msg, $secret);
    }

    private function checkStatus($paygolTransactionId)
    {
        try {
            // Validate payment against Paygol API
            $paygol = new PaygolApi(
                Configuration::get('TOKEN_SERVICE'),
                Configuration::get('TOKEN_SECRET'),
                Configuration::get('ENVIRONMENT')
            );

            $response = $paygol->getPaymentStatus($paygolTransactionId);

            if (property_exists((object) $response, 'payment')) {
                // Successful validation, validate payment status
                if ($response['payment']['status'] === 'completed') {
                    return true;
                }
            }
        } catch (\Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 2);
        }

        return false;
    }

    private function markAsCompleted($orderId)
    {
        // The order is marked as paid
        $order = new Order($orderId);
        $PS_OS_PAYMENT = Configuration::get('PS_OS_PAYMENT');

        if ($PS_OS_PAYMENT != $order->getCurrentState()) {
            $order->setCurrentState($PS_OS_PAYMENT);
            $order->save();
        }

        return true;
    }

    private function markAsFailed($orderId)
    {
        // Get Order by Cart Id
        $order = new Order($orderId);

        $PS_OS_ERROR = Configuration::get('PS_OS_ERROR');
        if ($PS_OS_ERROR != $order->getCurrentState()) {
            $order->setCurrentState($PS_OS_ERROR);
            $order->save();
        }

        return true;
    }
}
