<?php

/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2022 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

if (!defined('_PS_VERSION_')) {
    exit();
}

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

use Paygol\PaygolCore\PaygolApi;
use Paygol\PaygolCore\EnvironmentEnum;

class PaygolPrestaShop extends PaymentModule
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'paygolprestashop';
        $this->tab = 'payments_gateways';
        $this->author = 'Paygol';
        $this->need_instance = 1;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        //Always update, because prestashop doesn't accept version coming from another variable (MP_VERSION)
        $this->version = '1.2.2';
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Paygol');
        $this->description = $this->l(
            'Activa Paygol y permite a tus clientes pagar con los principales métodos de pago en Chile y Latinoamérica.'
        );

        $this->confirmUninstall = $this->l(
            'Al desinstalar este módulo, ya no podrás seguir procesando pagos con Paygol. ¿Está seguro que deseas continuar?'
        );

        $this->ps_version = _PS_VERSION_;
        $this->assets_ext_min = !_PS_MODE_DEV_ ? '.min' : '';
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        if (extension_loaded('curl') == false) {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

        /*
         * We generate the new order state
         */
        if (!$this->installOrderState()) {
            return false;
        }

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('displayPaymentReturn');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $this->context->smarty->assign('module_dir', $this->_path);

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        /**
         * If values have been submitted in the form, process.
         */
        if (((bool) Tools::isSubmit('submitPaygolprestashopModule')) == true) {
            if ($this->postProcess()) {
                $output = $this->displayConfirmation($this->l('Su configuración ha sido actualizada')) . $output;
            } else {
                $output = $output . $this->displayError($this->l('At least one of the fields is incorrect, please check'));
            }
        }

        return $output . $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitPaygolprestashopModule';
        $helper->currentIndex =
            $this->context->link->getAdminLink('AdminModules', false) .
            '&configure=' .
            $this->name .
            '&tab_module=' .
            $this->tab .
            '&module_name=' .
            $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFormValues() /* Add values for your inputs */,
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        return $helper->generateForm([$this->getConfigForm()]);
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return [
            'form' => [
                'legend' => [
                    'title' => $this->l('Configuración de la cuenta'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('ID de servicio de Paygol'),
                        'name' => 'TOKEN_SERVICE',
                        'size' => 20,
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Shared secret'),
                        'name' => 'TOKEN_SECRET',
                        'size' => 40,
                        'required' => true,
                    ],
                    [
                        'type' => 'radio',
                        'label' => $this->l('Ambiente:'),
                        'name' => 'ENVIRONMENT',
                        'required' => true,
                        'class' => 't',
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'development_env',
                                'value' => EnvironmentEnum::DEVELOPMENT,
                                'label' => $this->l('Integración'),
                            ],
                            [
                                'id' => 'production_env',
                                'value' => EnvironmentEnum::PRODUCTION,
                                'label' => $this->l('Producción'),
                            ],
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Guardar cambios'),
                ],
            ],
        ];
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return [
            'TOKEN_SERVICE' => Configuration::get('TOKEN_SERVICE'),
            'TOKEN_SECRET' => Configuration::get('TOKEN_SECRET'),
            'ENVIRONMENT' => Configuration::get('ENVIRONMENT'),
        ];
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        $all_values = true;

        // All values are required for this module
        foreach (array_keys($form_values) as $key) {
            if (empty(Tools::getValue($key))) {
                $all_values = false;
            } else {
                Configuration::updateValue($key, Tools::getValue($key));
            }
        }

        return $all_values;
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookBackOfficeHeader()
    {
        $this->hookDisplayBackOfficeHeader();
    }

    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') === $this->name) {
            $this->context->controller->addJS($this->_path . 'views/js/back.js');
            $this->context->controller->addCSS($this->_path . 'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path . '/views/js/front.js');
        $this->context->controller->addCSS($this->_path . '/views/css/front.css');
    }

    /**
     * Return payment options available for PS 1.7+
     *
     * @param array Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        // Country Billing info
        $billing = new Address($params['cart']->id_address_invoice);
        $billing_country = new Country($billing->id_country);
        return $this->showAllPaymentPlatforms($billing_country);
    }

    // Show all payment methods supported by Paygol
    public function showAllPaymentPlatforms($billing_country)
    {
        $externalOptions = [];
        try {
            // Init Paygol Core
            $paygol = new PaygolApi(
                Configuration::get('TOKEN_SERVICE'),
                Configuration::get('TOKEN_SECRET'),
                Configuration::get('ENVIRONMENT')
            );
            $paymentMethods = $paygol->getPaymentMethods($billing_country->iso_code);

            $action = $this->context->link->getModuleLink($this->name, 'redirect', [], true);
            if (property_exists((object) $paymentMethods, 'methods')) {
                $paymentTypes = $paymentMethods['methods'];
                foreach ($paymentTypes as &$paymentType) {
                    if (property_exists((object) $paymentType, 'name')) {
                        $paymentInfos = $this->context->smarty->fetch($this->local_path . 'views/templates/front/payment_method_info.tpl');
                        $paymentOption = new PaymentOption();
                        $paymentOption
                            ->setModuleName($paymentType['name'])
                            ->setCallToActionText($paymentType['name'])
                            ->setAction($action)
                            ->setLogo($paymentType['image_164x64'])
                            ->setInputs([
                                'payment_code' => [
                                    'name' => 'paygol_code',
                                    'type' => 'hidden',
                                    'value' => $paymentType['code'],
                                ],
                                'payment_name' => [
                                    'name' => 'paygol_name',
                                    'type' => 'hidden',
                                    'value' => $paymentType['name'],
                                ],
                            ])
                            ->setAdditionalInformation($paymentInfos);
                        array_push($externalOptions, $paymentOption);
                    }
                }
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 3, null, null, null, true);
        }
        return $externalOptions;
    }

    /**
     * This hook is used to display the order confirmation page.
     * XXX FIXME
     */
    public function hookDisplayPaymentReturn($params)
    {
        if ($this->active == false) {
            return null;
        }

        $nameOrderRef = isset($params['order']) ? 'order' : 'objOrder';
        $order = $params[$nameOrderRef];

        try {
            $payment = $order->getOrderPaymentCollection();

            if ($order->getCurrentOrderState()->id == Configuration::get('PS_OS_PAYMENT')) {
                $this->context->smarty->assign('status', 'ok');
            }
        } catch (Exception $ex) {
            $this->logger->error('Error en hookPaymentReturn: ' . $ex->getMessage());
        }

        $currency = new Currency($params['cart']->id_currency);
        $this->context->smarty->assign([
            'paygol_transaction_id' => $payment[0]->transaction_id ?? '',
            'total' => Tools::displayPrice($order->total_paid, $currency, false),
            'shop_name' => Configuration::get('PS_SHOP_NAME'),
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/hook/confirmation.tpl');
    }

    /*
     * Function for generate the order state
     */
    public function installOrderState()
    {
        if (Configuration::get('PS_OS_PAYGOL_PENDING_PAYMENT') < 1) {
            $order_state = new OrderState();
            $order_state->send_email = false;
            $order_state->module_name = $this->name;
            $order_state->invoice = false;
            $order_state->color = '#98c3ff';

            // Nota: debido a este error, https://github.com/PrestaShop/PrestaShop/issues/26553
            // El estado de la orden no podrá ser validada, por lo tanto esta propiedad deberá ser falsa.
            // Cuando esté corregido, este campo puede volver a ser verdadero.
            $order_state->logable = false;
            /* ^^^ Leer comentario inmediatamente superior a esta línea ^^^ */

            $order_state->shipped = false;
            $order_state->unremovable = false;
            $order_state->delivery = false;
            $order_state->hidden = false;
            $order_state->paid = false;
            $order_state->deleted = false;
            $order_state->name = array_fill(0, 10, $this->l('Pendiente de pago en Paygol'));
            $order_state->template = array_fill(0, 10, 'pending');

            if ($order_state->add()) {
                // We save the order State ID in Configuration database
                Configuration::updateValue('PS_OS_PAYGOL_PENDING_PAYMENT', $order_state->id);
            } else {
                return false;
            }
        }
        return true;
    }
}
